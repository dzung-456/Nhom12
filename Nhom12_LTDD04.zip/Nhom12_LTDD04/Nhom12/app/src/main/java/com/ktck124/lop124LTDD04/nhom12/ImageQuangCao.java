package com.ktck124.lop124LTDD04.nhom12;

public class ImageQuangCao {
    private int imganh;

    public ImageQuangCao(int imganh) {
        this.imganh = imganh;
    }

    public int getImganh() {
        return imganh;
    }

    public void setImganh(int imganh) {
        this.imganh = imganh;
    }
}
