package com.ktck124.lop124LTDD04.nhom12;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.example.apprestaurant.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class Navigation extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;
    private FrameLayout fragmentContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);

        bottomNavigationView = findViewById(R.id.ngv_bottomNavigation);
        fragmentContainer = findViewById(R.id.ngv_viewPager);

        // Load default fragment on first launch
        if (savedInstanceState == null) {
            replaceFragment(new HomeFragment());
        }

        // Set up BottomNavigationView item selection listener
        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment;
            switch (item.getItemId()) {
                case R.id.home:
                    selectedFragment = new HomeFragment();
                    break;
                case R.id.order:
                    selectedFragment = new OrderFragment();
                    break;
                case R.id.book:
                    selectedFragment = new BookFragment();
                    break;
                case R.id.favourite:
                    selectedFragment = new FavouriteFragment();
                    break;
                case R.id.account:
                    selectedFragment = new AccountFragment();
                    break;
                default:
                    return false;
            }
            replaceFragment(selectedFragment);
            return true;
        });

        // Handle window insets for proper layout adjustments
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    /**
     * Hides the BottomNavigationView.
     */
    public void hideBottomNavigationView() {
        bottomNavigationView.setVisibility(View.GONE);
    }

    /**
     * Navigates to a specific fragment and updates the BottomNavigationView state.
     *
     * @param menuItemId The ID of the menu item to navigate to.
     */
    public void navigateToFragment(int menuItemId) {
        Fragment selectedFragment;
        switch (menuItemId) {
            case R.id.home:
                selectedFragment = new HomeFragment();
                break;
            case R.id.order:
                selectedFragment = new OrderFragment();
                break;
            case R.id.book:
                selectedFragment = new BookFragment();
                break;
            case R.id.favourite:
                selectedFragment = new FavouriteFragment();
                break;
            case R.id.account:
                selectedFragment = new AccountFragment();
                break;
            default:
                return;
        }
        replaceFragment(selectedFragment);
        bottomNavigationView.setSelectedItemId(menuItemId);
    }

    /**
     * Replaces the current fragment with the specified fragment.
     *
     * @param fragment The fragment to display.
     */
    private void replaceFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.ngv_viewPager, fragment)
                    .commit();
        }
    }
}
